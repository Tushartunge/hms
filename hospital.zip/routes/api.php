<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;

use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\BillingController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\PrescriptionController;
use App\Http\Controllers\MedicalTestController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\WaitingRoomController;

// Appointment Routes
Route::resource('appointments', AppointmentController::class);

// Billing Routes
Route::resource('billings', BillingController::class);

// routes/api.php

    Route::resource('doctors', DoctorController::class);
    
// waiting room route
Route::resource('waitingrooms', WaitingRoomController::class);


// Patient Routes
Route::resource('patients', PatientController::class);

// Prescription Routes
Route::resource('prescriptions', PrescriptionController::class);

// Medical Test Routes
Route::resource('medical-tests', MedicalTestController::class);

// User Routes
//Route::resource('users', UserController::class);

// Transaction Routes
Route::resource('transactions', TransactionController::class);

// Document Routes
Route::resource('documents', DocumentController::class);

// Role and Permission Routes
// Route::resource('roles', RoleController::class);
// Route::resource('permissions', RoleController::class);

// // Notification Routes
// Route::resource('notifications', NotificationController::class);


// rout for changing status as in consulting 
Route::put('waiting-room/{waitingRoomId}/start-consultation', [WaitingRoomController::class, 'startConsultation']);

// rout for changing status as completed 
Route::put('waiting-room/{waitingRoomId}/complete-consultation', [WaitingRoomController::class, 'completeConsultation']);



Route::get('/example', [ApiController::class, 'exampleMethod']);
Route::post('/submit', [ApiController::class, 'submitMethod']);


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
