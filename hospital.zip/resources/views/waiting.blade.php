<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waiting Room Management</title>
    <style>
        /* Basic Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 60%;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        .waiting-room-list ul {
            list-style-type: none;
            padding: 0;
        }

        .waiting-room-list li {
            padding: 10px;
            margin: 5px;
            background-color: #f1f1f1;
            border-radius: 5px;
            cursor: pointer;
        }

        .waiting-room-list li:hover {
            background-color: #e0e0e0;
        }

        .patient-details {
            display: none;
            margin-top: 20px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .message {
            margin-top: 20px;
            text-align: center;
            padding: 10px;
            font-size: 18px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Waiting Room Management</h1>

        <!-- List of Waiting Room Entries -->
        <div class="waiting-room-list">
            <h2>Waiting Room List</h2>
            <ul id="waiting-room-list">
                <!-- List of waiting room entries will be dynamically added here -->
            </ul>
        </div>

        <!-- Patient Details and Status Change -->
        <div class="patient-details" id="patient-details">
            <h2>Patient Details</h2>
            <p id="patient-name">Patient Name: <span id="patient-name-value"></span></p>
            <p id="appointment-id">Appointment ID: <span id="appointment-id-value"></span></p>
            <p id="status">Status: <span id="status-value">Waiting</span></p>

            <!-- Status Change Buttons -->
            <button id="start-consultation-btn" onclick="changeStatus('in_consultation')">Start Consultation</button>
            <button id="complete-consultation-btn" onclick="changeStatus('completed')">Complete Consultation</button>
        </div>
        
        <!-- Error/Success message -->
        <div id="message" class="message"></div>
    </div>

    <script>
    // Fetch waiting room data from the backend API
    async function loadWaitingRoomList() {
        try {
            const response = await fetch('http://127.0.0.1:8000/api/waitingrooms');
            const waitingRooms = await response.json();

            const waitingRoomList = document.getElementById('waiting-room-list');
            waitingRoomList.innerHTML = ''; // Clear existing list

            waitingRooms.forEach(room => {
                const listItem = document.createElement('li');
                listItem.textContent = `Waiting Room ID: ${room.id} | Patient Name: ${room.patient.name} || Patient ID: ${room.patient.id} | Appointment ID: ${room.appointment.id}`;
                listItem.onclick = () => showPatientDetails(room);
                waitingRoomList.appendChild(listItem);
            });
        } catch (error) {
            console.error('Error fetching waiting room data:', error);
        }
    }

    // Function to show patient details and enable status change
    function showPatientDetails(room) {
        // Show the patient details section
        const patientDetailsSection = document.getElementById('patient-details');
        patientDetailsSection.style.display = 'block';

        // Set the patient details
       // document.getElementById('patient-id-value').textContent = room.patient.id;
        document.getElementById('patient-name-value').textContent = room.patient.name;
        document.getElementById('appointment-id-value').textContent = room.appointment.id;
        document.getElementById('status-value').textContent = room.status.charAt(0).toUpperCase() + room.status.slice(1);

        // Enable buttons based on the current status
        const startButton = document.getElementById('start-consultation-btn');
        const completeButton = document.getElementById('complete-consultation-btn');

        if (room.status === 'waiting') {
            startButton.disabled = false;
            completeButton.disabled = true;
        } else if (room.status === 'in_consultation') {
            startButton.disabled = true;
            completeButton.disabled = false;
        } else {
            startButton.disabled = true;
            completeButton.disabled = true;
        }

        // Store the selected waiting room for status change
        window.selectedRoom = room;
    }

    // Function to change the status
    async function changeStatus(newStatus) {
        try {
            const response = await fetch(`/api/waiting-rooms/${window.selectedRoom.id}/status`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: newStatus }),
            });

            const result = await response.json();

            // Update the UI with the new status
            document.getElementById('status-value').textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);

            showMessage(`${window.selectedRoom.patient.name}'s status updated to "${newStatus}".`, 'success');

            // Disable buttons after status change
            const startButton = document.getElementById('start-consultation-btn');
            const completeButton = document.getElementById('complete-consultation-btn');
            startButton.disabled = true;
            completeButton.disabled = true;
        } catch (error) {
            console.error('Error updating status:', error);
            showMessage('Failed to update status. Please try again later.', 'error');
        }
    }

    // Function to display success or error messages
    function showMessage(message, type) {
        const messageElement = document.getElementById('message');
        messageElement.textContent = message;
        messageElement.className = `message ${type}`;
    }

    // Load the waiting room list when the page loads
    window.onload = loadWaitingRoomList;
</script>

</body>
</html>
